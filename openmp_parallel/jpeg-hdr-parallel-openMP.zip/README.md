jpeg-hdr
========

Serial implementation of HDR image stitching

you need libjpeg on your pc to compile and run this example

Compile:
    $ make

Run:
    $ make run

Output:
    hdr.JPG in samples folder
